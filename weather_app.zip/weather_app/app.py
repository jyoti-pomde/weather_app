from flask import Flask, render_template, request
import requests

app = Flask(__name__)

API_KEY = "6f8dcf1232e0199b9bd0aeabe3fcf4ad"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/weather", methods=["POST"])
def weather():
    city = request.form["city"]

    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    data = response.json()

    # Debug (optional)
    print(data)

    if data.get("cod") != 200:
        return render_template("index.html", error="City not found or invalid API key")

    weather_data = {
        "city": city,
        "temp": data["main"]["temp"],
        "humidity": data["main"]["humidity"],
        "desc": data["weather"][0]["description"]
    }

    return render_template("index.html", data=weather_data)

if __name__ == "__main__":
    app.run(debug=True)